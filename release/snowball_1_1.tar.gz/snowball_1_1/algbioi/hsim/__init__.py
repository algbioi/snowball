"""
    Functionality for the simulated data for the haplotype reconstruction.
"""
