""""
    Contains the gene haplotype reconstruction algorithm.
"""
