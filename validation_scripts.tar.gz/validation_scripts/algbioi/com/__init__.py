"""
    Contains general purpose modules that can be reused elsewhere.
"""
__author__ = 'ivan'
