This directory contains miscellaneous validation scripts. 

This is distributed in a hope that it can be useful.

Please use the main distribution of the software to branch from.